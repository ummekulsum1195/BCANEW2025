"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { FileText, Plus, Calendar, Trash2, Download, Upload } from "lucide-react"

interface MedicalTest {
  id: string
  testName: string
  testDate: string
  testType: string
  laboratory: string
  results?: string
  notes?: string
  reportUrl?: string
  createdAt: string
}

export default function MedicalTestsPage() {
  const [tests, setTests] = useState<MedicalTest[]>([])
  const [newTest, setNewTest] = useState<Omit<MedicalTest, "id" | "createdAt">>({
    testName: "",
    testDate: "",
    testType: "",
    laboratory: "",
    results: "",
    notes: "",
  })

  useEffect(() => {
    // Load tests from localStorage
    const savedTests = localStorage.getItem("medicalTests")
    if (savedTests) {
      setTests(JSON.parse(savedTests))
    }
  }, [])

  // Ensure we're saving tests to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("medicalTests", JSON.stringify(tests))
  }, [tests])

  const addTest = () => {
    if (!newTest.testName || !newTest.testDate || !newTest.testType) {
      toast({
        title: "Missing information",
        description: "Please provide test name, date, and type",
        variant: "destructive",
      })
      return
    }

    const test: MedicalTest = {
      ...newTest,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }

    setTests([...tests, test])
    setNewTest({
      testName: "",
      testDate: "",
      testType: "",
      laboratory: "",
      results: "",
      notes: "",
    })

    toast({
      title: "Test added",
      description: "Medical test has been added successfully",
    })
  }

  const deleteTest = (id: string) => {
    setTests(tests.filter((test) => test.id !== id))
    toast({
      title: "Test deleted",
      description: "Medical test has been removed",
    })
  }

  const handleFileUpload = (id: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // In a real app, you would upload this file to a server
    // For this demo, we'll simulate a file URL
    const fakeFileUrl = URL.createObjectURL(file)

    setTests(
      tests.map((test) => {
        if (test.id === id) {
          return {
            ...test,
            reportUrl: fakeFileUrl,
          }
        }
        return test
      }),
    )

    toast({
      title: "Report uploaded",
      description: `File "${file.name}" has been attached to the test`,
    })
  }

  const updateTestResults = (id: string, results: string) => {
    setTests(
      tests.map((test) => {
        if (test.id === id) {
          return {
            ...test,
            results,
          }
        }
        return test
      }),
    )

    toast({
      title: "Results updated",
      description: "Test results have been saved",
    })
  }

  // Sort tests by date, most recent first
  const sortedTests = [...tests].sort((a, b) => new Date(b.testDate).getTime() - new Date(a.testDate).getTime())

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Medical Tests & Reports</h1>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="all">All Tests</TabsTrigger>
          <TabsTrigger value="add">Add New Test</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          {sortedTests.length === 0 ? (
            <Card>
              <CardContent className="py-10 text-center">
                <FileText className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                <p className="text-muted-foreground">No medical tests found</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Add your medical tests to keep track of your health records
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {sortedTests.map((test) => (
                <Card key={test.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <FileText className="h-5 w-5 text-blue-500" />
                          {test.testName}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(test.testDate).toLocaleDateString()}
                          <Badge variant="outline">{test.testType}</Badge>
                        </CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => deleteTest(test.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-medium">Laboratory/Facility:</p>
                        <p className="text-sm text-gray-600">{test.laboratory}</p>
                      </div>

                      {test.results ? (
                        <div>
                          <p className="text-sm font-medium">Results:</p>
                          <p className="text-sm text-gray-600 whitespace-pre-line">{test.results}</p>
                        </div>
                      ) : (
                        <div>
                          <p className="text-sm font-medium">Results:</p>
                          <Textarea
                            placeholder="Enter test results here"
                            className="mt-1"
                            onChange={(e) => updateTestResults(test.id, e.target.value)}
                          />
                          <Button
                            size="sm"
                            className="mt-2"
                            onClick={() =>
                              updateTestResults(
                                test.id,
                                document.querySelector<HTMLTextAreaElement>(`textarea`)?.value || "",
                              )
                            }
                          >
                            Save Results
                          </Button>
                        </div>
                      )}

                      {test.notes && (
                        <div>
                          <p className="text-sm font-medium">Notes:</p>
                          <p className="text-sm text-gray-600">{test.notes}</p>
                        </div>
                      )}

                      <div className="pt-2">
                        {test.reportUrl ? (
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm" onClick={() => window.open(test.reportUrl, "_blank")}>
                              <Download className="h-4 w-4 mr-2" />
                              View Report
                            </Button>
                            <p className="text-xs text-gray-500">Report attached</p>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <label className="cursor-pointer">
                              <Button variant="outline" size="sm" asChild>
                                <span>
                                  <Upload className="h-4 w-4 mr-2" />
                                  Upload Report
                                </span>
                              </Button>
                              <input
                                type="file"
                                className="hidden"
                                accept=".pdf,.jpg,.jpeg,.png"
                                onChange={(e) => handleFileUpload(test.id, e)}
                              />
                            </label>
                            <p className="text-xs text-gray-500">PDF, JPG, PNG</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="add">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-blue-500" />
                Add New Medical Test
              </CardTitle>
              <CardDescription>Record details of your medical tests and lab work</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Test Name</label>
                  <Input
                    placeholder="e.g., Blood Glucose, CBC, X-Ray"
                    value={newTest.testName}
                    onChange={(e) => setNewTest({ ...newTest, testName: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Test Date</label>
                  <Input
                    type="date"
                    value={newTest.testDate}
                    onChange={(e) => setNewTest({ ...newTest, testDate: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Test Type</label>
                  <select
                    className="w-full rounded-md border border-input bg-background px-3 py-2"
                    value={newTest.testType}
                    onChange={(e) => setNewTest({ ...newTest, testType: e.target.value })}
                  >
                    <option value="">Select Type</option>
                    <option value="Blood Test">Blood Test</option>
                    <option value="Imaging">Imaging</option>
                    <option value="Physical Exam">Physical Exam</option>
                    <option value="Urine Test">Urine Test</option>
                    <option value="Biopsy">Biopsy</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Laboratory/Facility</label>
                  <Input
                    placeholder="Where the test was conducted"
                    value={newTest.laboratory}
                    onChange={(e) => setNewTest({ ...newTest, laboratory: e.target.value })}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium">Results (Optional)</label>
                  <Textarea
                    placeholder="Enter test results if available"
                    value={newTest.results}
                    onChange={(e) => setNewTest({ ...newTest, results: e.target.value })}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium">Notes (Optional)</label>
                  <Textarea
                    placeholder="Any additional notes about this test"
                    value={newTest.notes}
                    onChange={(e) => setNewTest({ ...newTest, notes: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={addTest}>
                <Plus className="h-4 w-4 mr-2" />
                Add Medical Test
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
