"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import MedicationReminder from "@/components/medication-reminder"
import QuickTimer from "@/components/quick-timer"
import { Clock, Pill, Calendar, FileText } from "lucide-react"
import Link from "next/link"

interface User {
  username: string
  name: string
  email: string
}

interface DashboardStats {
  medications: {
    upcoming: number
    taken: number
    total: number
  }
  appointments: {
    upcoming: number
    past: number
  }
  tests: number
}

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null)
  const [stats, setStats] = useState<DashboardStats>({
    medications: {
      upcoming: 0,
      taken: 0,
      total: 0,
    },
    appointments: {
      upcoming: 0,
      past: 0,
    },
    tests: 0,
  })

  useEffect(() => {
    // Get user data
    const userData = localStorage.getItem("currentUser")
    if (userData) {
      setUser(JSON.parse(userData))
    }

    // Get medication stats
    const medications = JSON.parse(localStorage.getItem("medications") || "[]")
    const upcoming = medications.filter((med: any) => !med.taken).length
    const taken = medications.filter((med: any) => med.taken).length

    // Get appointment stats
    const appointments = JSON.parse(localStorage.getItem("appointments") || "[]")
    const upcomingAppts = appointments.filter((appt: any) => appt.status === "upcoming").length
    const pastAppts = appointments.filter((appt: any) => appt.status !== "upcoming").length

    // Get test stats
    const tests = JSON.parse(localStorage.getItem("medicalTests") || "[]").length

    setStats({
      medications: {
        upcoming,
        taken,
        total: medications.length,
      },
      appointments: {
        upcoming: upcomingAppts,
        past: pastAppts,
      },
      tests,
    })
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-1">
          <h1 className="text-2xl font-bold mb-6">Welcome, {user?.name || "User"}</h1>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Link href="/dashboard" className="block">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Upcoming Medications</CardDescription>
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <Pill className="h-5 w-5 text-blue-500" />
                    {stats.medications.upcoming}
                  </CardTitle>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/dashboard/appointments" className="block">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Upcoming Appointments</CardDescription>
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-purple-500" />
                    {stats.appointments.upcoming}
                  </CardTitle>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/dashboard/tests" className="block">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Medical Tests</CardDescription>
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <FileText className="h-5 w-5 text-green-500" />
                    {stats.tests}
                  </CardTitle>
                </CardHeader>
              </Card>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="md:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Pill className="h-5 w-5 text-blue-500" />
                    Medications
                  </CardTitle>
                  <CardDescription>Manage your medication schedule</CardDescription>
                </CardHeader>
                <CardContent>
                  <MedicationReminder />
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-blue-500" />
                    Quick Timer
                  </CardTitle>
                  <CardDescription>Set a timer for medications</CardDescription>
                </CardHeader>
                <CardContent>
                  <QuickTimer />
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
