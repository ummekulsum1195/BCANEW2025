"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Calendar, Clock, MapPin, User, Plus, Trash2, CheckCircle, AlertCircle, Hospital } from "lucide-react"

interface Appointment {
  id: string
  doctorName: string
  specialty: string
  location: string
  date: string
  time: string
  notes?: string
  status: "upcoming" | "completed" | "cancelled"
  followUp?: string
  createdAt: string
}

export default function AppointmentsPage() {
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [newAppointment, setNewAppointment] = useState<Omit<Appointment, "id" | "status" | "createdAt">>({
    doctorName: "",
    specialty: "",
    location: "",
    date: "",
    time: "",
    notes: "",
  })

  useEffect(() => {
    // Load appointments from localStorage
    const savedAppointments = localStorage.getItem("appointments")
    if (savedAppointments) {
      setAppointments(JSON.parse(savedAppointments))
    }
  }, [])

  // Ensure we're saving appointments to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("appointments", JSON.stringify(appointments))
  }, [appointments])

  const addAppointment = () => {
    if (!newAppointment.doctorName || !newAppointment.date || !newAppointment.time) {
      toast({
        title: "Missing information",
        description: "Please provide doctor name, date, and time",
        variant: "destructive",
      })
      return
    }

    const appointment: Appointment = {
      ...newAppointment,
      id: Date.now().toString(),
      status: "upcoming",
      createdAt: new Date().toISOString(),
    }

    setAppointments([...appointments, appointment])
    setNewAppointment({
      doctorName: "",
      specialty: "",
      location: "",
      date: "",
      time: "",
      notes: "",
    })

    toast({
      title: "Appointment added",
      description: "Your appointment has been scheduled",
    })
  }

  const deleteAppointment = (id: string) => {
    setAppointments(appointments.filter((appointment) => appointment.id !== id))
    toast({
      title: "Appointment deleted",
      description: "The appointment has been removed",
    })
  }

  const updateAppointmentStatus = (id: string, status: Appointment["status"], followUp?: string) => {
    setAppointments(
      appointments.map((appointment) => {
        if (appointment.id === id) {
          return {
            ...appointment,
            status,
            followUp,
          }
        }
        return appointment
      }),
    )

    toast({
      title: `Appointment ${status}`,
      description:
        status === "completed" ? "Appointment has been marked as completed" : "Appointment has been cancelled",
    })
  }

  // Filter appointments by status
  const upcomingAppointments = appointments
    .filter((app) => app.status === "upcoming")
    .sort((a, b) => new Date(a.date + "T" + a.time).getTime() - new Date(b.date + "T" + b.time).getTime())

  const pastAppointments = appointments
    .filter((app) => app.status !== "upcoming")
    .sort((a, b) => new Date(b.date + "T" + b.time).getTime() - new Date(a.date + "T" + a.time).getTime())

  // Format time for display
  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    return `${hour % 12 || 12}:${minutes} ${hour >= 12 ? "PM" : "AM"}`
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Hospital & Doctor Appointments</h1>

      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="past">Past Appointments</TabsTrigger>
          <TabsTrigger value="add">Schedule New</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming">
          {upcomingAppointments.length === 0 ? (
            <Card>
              <CardContent className="py-10 text-center">
                <Calendar className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                <p className="text-muted-foreground">No upcoming appointments</p>
                <p className="text-sm text-muted-foreground mt-1">Schedule a new appointment to see it here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {upcomingAppointments.map((appointment) => (
                <Card key={appointment.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <User className="h-5 w-5 text-blue-500" />
                          Dr. {appointment.doctorName}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          {appointment.specialty && <Badge variant="outline">{appointment.specialty}</Badge>}
                        </CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => deleteAppointment(appointment.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span>{new Date(appointment.date).toLocaleDateString()}</span>
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span>{formatTime(appointment.time)}</span>
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-gray-500" />
                        <span>{appointment.location}</span>
                      </div>

                      {appointment.notes && (
                        <div className="pt-2">
                          <p className="text-sm font-medium">Notes:</p>
                          <p className="text-sm text-gray-600">{appointment.notes}</p>
                        </div>
                      )}

                      <div className="pt-3 flex flex-wrap gap-2">
                        <Button size="sm" onClick={() => updateAppointmentStatus(appointment.id, "completed")}>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Mark as Attended
                        </Button>

                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-500"
                          onClick={() => updateAppointmentStatus(appointment.id, "cancelled")}
                        >
                          <AlertCircle className="h-4 w-4 mr-2" />
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="past">
          {pastAppointments.length === 0 ? (
            <Card>
              <CardContent className="py-10 text-center">
                <Calendar className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                <p className="text-muted-foreground">No past appointments</p>
                <p className="text-sm text-muted-foreground mt-1">Your appointment history will appear here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {pastAppointments.map((appointment) => (
                <Card key={appointment.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <User className="h-5 w-5 text-blue-500" />
                          Dr. {appointment.doctorName}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          {appointment.specialty && <Badge variant="outline">{appointment.specialty}</Badge>}
                          <Badge
                            variant={appointment.status === "completed" ? "default" : "destructive"}
                            className={appointment.status === "completed" ? "bg-green-100 text-green-800" : ""}
                          >
                            {appointment.status === "completed" ? "Attended" : "Cancelled"}
                          </Badge>
                        </CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => deleteAppointment(appointment.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span>{new Date(appointment.date).toLocaleDateString()}</span>
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span>{formatTime(appointment.time)}</span>
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-gray-500" />
                        <span>{appointment.location}</span>
                      </div>

                      {appointment.notes && (
                        <div className="pt-2">
                          <p className="text-sm font-medium">Notes:</p>
                          <p className="text-sm text-gray-600">{appointment.notes}</p>
                        </div>
                      )}

                      {appointment.status === "completed" && (
                        <div className="pt-2">
                          <p className="text-sm font-medium">Follow-up Notes:</p>
                          {appointment.followUp ? (
                            <p className="text-sm text-gray-600">{appointment.followUp}</p>
                          ) : (
                            <div>
                              <Textarea
                                placeholder="Add follow-up notes from this appointment"
                                className="mt-1"
                                id={`followup-${appointment.id}`}
                              />
                              <Button
                                size="sm"
                                className="mt-2"
                                onClick={() => {
                                  const notes = document.querySelector<HTMLTextAreaElement>(
                                    `#followup-${appointment.id}`,
                                  )?.value
                                  updateAppointmentStatus(appointment.id, "completed", notes)
                                }}
                              >
                                Save Notes
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="add">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Hospital className="h-5 w-5 text-blue-500" />
                Schedule New Appointment
              </CardTitle>
              <CardDescription>Add details for your upcoming doctor or hospital visit</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Doctor Name</label>
                  <Input
                    placeholder="Doctor's name"
                    value={newAppointment.doctorName}
                    onChange={(e) => setNewAppointment({ ...newAppointment, doctorName: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Specialty</label>
                  <select
                    className="w-full rounded-md border border-input bg-background px-3 py-2"
                    value={newAppointment.specialty}
                    onChange={(e) => setNewAppointment({ ...newAppointment, specialty: e.target.value })}
                  >
                    <option value="">Select Specialty</option>
                    <option value="Primary Care">Primary Care</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Dermatology">Dermatology</option>
                    <option value="Endocrinology">Endocrinology</option>
                    <option value="Gastroenterology">Gastroenterology</option>
                    <option value="Neurology">Neurology</option>
                    <option value="Obstetrics & Gynecology">Obstetrics & Gynecology</option>
                    <option value="Oncology">Oncology</option>
                    <option value="Ophthalmology">Ophthalmology</option>
                    <option value="Orthopedics">Orthopedics</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="Psychiatry">Psychiatry</option>
                    <option value="Urology">Urology</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Date</label>
                  <Input
                    type="date"
                    value={newAppointment.date}
                    onChange={(e) => setNewAppointment({ ...newAppointment, date: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Time</label>
                  <Input
                    type="time"
                    value={newAppointment.time}
                    onChange={(e) => setNewAppointment({ ...newAppointment, time: e.target.value })}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium">Location/Hospital</label>
                  <Input
                    placeholder="Hospital or clinic name and address"
                    value={newAppointment.location}
                    onChange={(e) => setNewAppointment({ ...newAppointment, location: e.target.value })}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium">Notes (Optional)</label>
                  <Textarea
                    placeholder="Reason for visit, questions to ask, etc."
                    value={newAppointment.notes}
                    onChange={(e) => setNewAppointment({ ...newAppointment, notes: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={addAppointment}>
                <Plus className="h-4 w-4 mr-2" />
                Schedule Appointment
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
