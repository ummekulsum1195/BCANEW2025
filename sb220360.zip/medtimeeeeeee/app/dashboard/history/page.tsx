"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Pill, Clock, Calendar } from "lucide-react"

interface Medication {
  id: string
  name: string
  time: string
  date?: string
  frequency: string
  notes?: string
  taken: boolean
  nextDose: string
  takenAt?: string
}

export default function HistoryPage() {
  const [medications, setMedications] = useState<Medication[]>([])

  useEffect(() => {
    // Load medication history
    const medsData = localStorage.getItem("medications")
    if (medsData) {
      const parsedMeds = JSON.parse(medsData)
      // Sort by taken date, most recent first
      const takenMeds = parsedMeds
        .filter((med: Medication) => med.taken)
        .sort((a: Medication, b: Medication) => {
          return new Date(b.takenAt || b.nextDose).getTime() - new Date(a.takenAt || a.nextDose).getTime()
        })

      setMedications(takenMeds)
    }
  }, [])

  // Format time for display
  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    return `${hour % 12 || 12}:${minutes} ${hour >= 12 ? "PM" : "AM"}`
  }

  // Group medications by date
  const groupedMedications: Record<string, Medication[]> = {}

  medications.forEach((med) => {
    const takenDate = new Date(med.takenAt || med.nextDose)
    const dateKey = takenDate.toLocaleDateString()

    if (!groupedMedications[dateKey]) {
      groupedMedications[dateKey] = []
    }

    groupedMedications[dateKey].push(med)
  })

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Medication History</h1>

      {Object.keys(groupedMedications).length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center">
            <p className="text-muted-foreground">No medication history found</p>
            <p className="text-sm text-muted-foreground mt-1">
              Your medication history will appear here once you start taking medications
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedMedications).map(([date, meds]) => (
            <div key={date}>
              <div className="flex items-center gap-2 mb-3">
                <Calendar className="h-5 w-5 text-blue-500" />
                <h2 className="text-lg font-semibold">{date}</h2>
              </div>

              <div className="grid gap-4">
                {meds.map((med) => (
                  <Card key={med.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold flex items-center gap-2">
                            <Pill className="h-4 w-4 text-green-500" />
                            {med.name}
                          </h3>
                          <div className="flex items-center gap-2 text-gray-500 mt-1">
                            <Clock className="h-4 w-4" />
                            <span>{formatTime(med.time)}</span>
                            <Badge variant="outline">{med.frequency}</Badge>
                          </div>
                          {med.notes && <p className="mt-2 text-sm text-gray-600">{med.notes}</p>}
                        </div>
                        <Badge variant="outline" className="bg-green-50">
                          Taken
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
