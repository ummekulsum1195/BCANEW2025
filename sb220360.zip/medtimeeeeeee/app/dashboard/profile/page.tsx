"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { User, Mail, Save } from "lucide-react"

interface UserProfile {
  username: string
  name: string
  email: string
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<UserProfile>({
    username: "",
    name: "",
    email: "",
  })

  useEffect(() => {
    // Load user profile from localStorage
    const userData = localStorage.getItem("currentUser")
    if (userData) {
      setProfile(JSON.parse(userData))
    }
  }, [])

  const handleSave = () => {
    // Save updated profile
    localStorage.setItem("currentUser", JSON.stringify(profile))

    // Update in users array if not admin
    if (profile.username !== "admin") {
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const updatedUsers = users.map((user: any) => {
        if (user.username === profile.username) {
          return { ...user, name: profile.name, email: profile.email }
        }
        return user
      })

      localStorage.setItem("users", JSON.stringify(updatedUsers))
    }

    toast({
      title: "Profile updated",
      description: "Your profile has been updated successfully",
    })
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">User Profile</h1>

      <Card>
        <CardHeader>
          <CardTitle>Personal Information</CardTitle>
          <CardDescription>Update your personal details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Username</label>
            <div className="relative">
              <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input value={profile.username} className="pl-10" disabled />
            </div>
            <p className="text-xs text-muted-foreground">Username cannot be changed</p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Full Name</label>
            <div className="relative">
              <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                value={profile.name}
                className="pl-10"
                onChange={(e) => setProfile({ ...profile, name: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                type="email"
                value={profile.email}
                className="pl-10"
                onChange={(e) => setProfile({ ...profile, email: e.target.value })}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSave}>
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
