"use client"

// Simplified toast implementation
import { createContext, useContext } from "react"

type ToastProps = {
  title?: string
  description?: string
  variant?: "default" | "destructive"
}

const ToastContext = createContext<{
  toast: (props: ToastProps) => void
}>({
  toast: () => {},
})

export const useToast = () => {
  const context = useContext(ToastContext)
  return context
}

export function toast(props: ToastProps) {
  // In a real implementation, this would show a toast notification
  // For simplicity, we're just using browser alerts
  if (typeof window !== "undefined") {
    alert(`${props.title}\n${props.description}`)
  }
}
