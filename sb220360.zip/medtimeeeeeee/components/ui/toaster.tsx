// Simplified toaster component
export function Toaster() {
  // This would normally render toast notifications
  // For simplicity, we're just returning an empty fragment
  return null
}
