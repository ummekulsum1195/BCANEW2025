"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Bell, LogOut, User } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export default function Navbar() {
  const router = useRouter()
  const [username, setUsername] = useState("")

  useEffect(() => {
    const userData = localStorage.getItem("currentUser")
    if (userData) {
      const user = JSON.parse(userData)
      setUsername(user.name)
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn")
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    })
    router.push("/login")
  }

  return (
    <header className="bg-white border-b sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/dashboard" className="text-xl font-bold text-blue-600 flex items-center gap-2">
          <Bell className="h-6 w-6" />
          MedTime Reminder
        </Link>

        <div className="flex items-center gap-4">
          <Link href="/dashboard/profile" className="flex items-center gap-2 text-sm">
            <User className="h-4 w-4" />
            {username}
          </Link>

          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </header>
  )
}
