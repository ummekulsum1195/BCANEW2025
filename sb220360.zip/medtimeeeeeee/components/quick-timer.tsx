"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Play, Pause, RotateCcw, Bell } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export default function QuickTimer() {
  const [minutes, setMinutes] = useState<number>(5)
  const [seconds, setSeconds] = useState<number>(0)
  const [isRunning, setIsRunning] = useState<boolean>(false)
  const [isPaused, setIsPaused] = useState<boolean>(false)
  const [audioEnabled, setAudioEnabled] = useState<boolean>(true)

  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    // Initialize audio
    const audio = new Audio("/alert.mp3")
    audio.preload = "auto"
    audioRef.current = audio

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current.src = ""
      }
    }
  }, [])

  useEffect(() => {
    if (isRunning && !isPaused) {
      timerRef.current = setInterval(() => {
        setSeconds((prevSeconds) => {
          if (prevSeconds === 0) {
            setMinutes((prevMinutes) => {
              if (prevMinutes === 0) {
                // Timer complete
                clearInterval(timerRef.current!)
                setIsRunning(false)
                handleTimerComplete()
                return 0
              }
              return prevMinutes - 1
            })
            return 59
          }
          return prevSeconds - 1
        })
      }, 1000)
    } else if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [isRunning, isPaused])

  const startTimer = () => {
    if (minutes <= 0 && seconds <= 0) {
      toast({
        title: "Invalid time",
        description: "Please set a time greater than zero",
        variant: "destructive",
      })
      return
    }

    setIsRunning(true)
    setIsPaused(false)
  }

  const pauseTimer = () => {
    setIsPaused(true)
  }

  const resumeTimer = () => {
    setIsPaused(false)
  }

  const resetTimer = () => {
    setIsRunning(false)
    setIsPaused(false)
    setMinutes(5)
    setSeconds(0)
  }

  const handleTimerComplete = () => {
    toast({
      title: "Timer Complete!",
      description: "Your medication timer has finished",
    })

    // Play audio alert if enabled
    if (audioEnabled && audioRef.current) {
      audioRef.current.play().catch((e) => console.error("Audio playback failed:", e))
    }
  }

  const formatTime = (value: number) => {
    return value.toString().padStart(2, "0")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center justify-center">
        {!isRunning ? (
          <div className="w-full max-w-xs space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Minutes</label>
                <Input
                  type="number"
                  min="0"
                  max="59"
                  value={minutes}
                  onChange={(e) => setMinutes(Number.parseInt(e.target.value) || 0)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Seconds</label>
                <Input
                  type="number"
                  min="0"
                  max="59"
                  value={seconds}
                  onChange={(e) => setSeconds(Number.parseInt(e.target.value) || 0)}
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button onClick={startTimer} className="flex-1">
                <Play className="h-4 w-4 mr-2" />
                Start Timer
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-center space-y-6">
            <div className="text-6xl font-mono font-semibold">
              {formatTime(minutes)}:{formatTime(seconds)}
            </div>

            <div className="flex items-center justify-center gap-4">
              {isPaused ? (
                <Button onClick={resumeTimer}>
                  <Play className="h-4 w-4 mr-2" />
                  Resume
                </Button>
              ) : (
                <Button onClick={pauseTimer}>
                  <Pause className="h-4 w-4 mr-2" />
                  Pause
                </Button>
              )}

              <Button variant="outline" onClick={resetTimer}>
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center justify-center">
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={audioEnabled} onChange={() => setAudioEnabled(!audioEnabled)} />
          <Bell className="h-4 w-4" />
          Enable sound when timer completes
        </label>
      </div>
    </div>
  )
}
