"use client"

import { useState, useEffect } from "react"
import { PlusCircle, CheckCircle, Clock, Pill } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

interface Medication {
  id: string
  name: string
  time: string
  date?: string
  frequency: string
  notes?: string
  taken: boolean
  nextDose: Date
  timer?: number // in minutes
  takenAt?: string // timestamp when medication was taken
}

export default function MedicationReminder() {
  const [medications, setMedications] = useState<Medication[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("medications")
      if (saved) {
        const parsed = JSON.parse(saved)
        return parsed.map((med: any) => ({
          ...med,
          nextDose: new Date(med.nextDose),
        }))
      }
    }
    return []
  })

  const [newMed, setNewMed] = useState({
    name: "",
    time: "",
    date: "",
    frequency: "daily",
    notes: "",
    timer: 0,
  })

  const [audioEnabled, setAudioEnabled] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("audioEnabled")
      return saved ? JSON.parse(saved) === true : true
    }
    return true
  })

  const [audio, setAudio] = useState<HTMLAudioElement | null>(null)

  useEffect(() => {
    const audioElement = new Audio("/alert.mp3")
    audioElement.preload = "auto"
    setAudio(audioElement)

    return () => {
      audioElement.pause()
      audioElement.src = ""
    }
  }, [])

  // Save medications to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("medications", JSON.stringify(medications))
  }, [medications])

  useEffect(() => {
    localStorage.setItem("audioEnabled", JSON.stringify(audioEnabled))
  }, [audioEnabled])

  // Check for medications that need to be taken
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date()

      medications.forEach((med) => {
        if (!med.taken && med.nextDose <= now) {
          // Show notification
          if (Notification.permission === "granted") {
            new Notification("Medication Reminder", {
              body: `Time to take ${med.name}`,
              icon: "/placeholder.svg?height=64&width=64",
            })
          }

          // Play audio alert if enabled
          if (audioEnabled && audio) {
            audio.play().catch((e) => console.error("Audio playback failed:", e))
          }

          // Show toast
          toast({
            title: "Medication Reminder",
            description: `Time to take ${med.name}`,
          })
        }
      })
    }, 30000) // Check every 30 seconds

    return () => clearInterval(interval)
  }, [medications, audioEnabled, audio])

  // Request notification permission
  useEffect(() => {
    if (Notification.permission !== "granted" && Notification.permission !== "denied") {
      Notification.requestPermission()
    }
  }, [])

  const addMedication = () => {
    if (!newMed.name || !newMed.time) {
      toast({
        title: "Missing information",
        description: "Please provide a medication name and time",
        variant: "destructive",
      })
      return
    }

    // Parse time and create next dose date
    const [hours, minutes] = newMed.time.split(":").map(Number)
    let nextDose = new Date()

    // If a specific date is selected, use that
    if (newMed.date) {
      nextDose = new Date(newMed.date)
      nextDose.setHours(hours, minutes, 0, 0)
    } else {
      nextDose.setHours(hours, minutes, 0, 0)

      // If the time has already passed today, set it for tomorrow
      if (nextDose < new Date()) {
        nextDose.setDate(nextDose.getDate() + 1)
      }
    }

    // If timer is set, use that instead of the scheduled time
    if (newMed.timer && newMed.timer > 0) {
      nextDose = new Date(Date.now() + newMed.timer * 60 * 1000)
    }

    const medication: Medication = {
      id: Date.now().toString(),
      name: newMed.name,
      time: newMed.time,
      date: newMed.date,
      frequency: newMed.frequency,
      notes: newMed.notes,
      taken: false,
      nextDose,
      timer: newMed.timer && newMed.timer > 0 ? newMed.timer : undefined,
    }

    setMedications([...medications, medication])
    setNewMed({
      name: "",
      time: "",
      date: "",
      frequency: "daily",
      notes: "",
      timer: 0,
    })

    toast({
      title: "Medication added",
      description: `${medication.name} has been added to your reminders`,
    })
  }

  const markAsTaken = (id: string) => {
    setMedications(
      medications.map((med) => {
        if (med.id === id) {
          // Calculate next dose based on frequency
          const nextDose = new Date(med.nextDose)

          if (med.frequency === "daily") {
            nextDose.setDate(nextDose.getDate() + 1)
          } else if (med.frequency === "weekly") {
            nextDose.setDate(nextDose.getDate() + 7)
          } else if (med.frequency === "twice-daily") {
            nextDose.setHours(nextDose.getHours() + 12)
          }

          return {
            ...med,
            taken: true,
            nextDose,
            takenAt: new Date().toISOString(), // Record when it was taken
          }
        }
        return med
      }),
    )

    toast({
      title: "Medication taken",
      description: "Great job staying on top of your health!",
    })
  }

  const deleteMedication = (id: string) => {
    setMedications(medications.filter((med) => med.id !== id))

    toast({
      title: "Medication deleted",
      description: "The medication has been removed from your reminders",
    })
  }

  const upcomingMeds = medications.filter((med) => !med.taken)
  const takenMeds = medications.filter((med) => med.taken)

  // Format time for display
  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    return `${hour % 12 || 12}:${minutes} ${hour >= 12 ? "PM" : "AM"}`
  }

  const formatRemainingTime = (nextDose: Date) => {
    const now = new Date()
    const diff = nextDose.getTime() - now.getTime()

    if (diff <= 0) return "Now"

    const minutes = Math.floor(diff / (1000 * 60))
    const hours = Math.floor(minutes / 60)
    const remainingMinutes = minutes % 60

    if (hours > 0) {
      return `${hours}h ${remainingMinutes}m`
    }
    return `${remainingMinutes}m`
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PlusCircle className="h-5 w-5 text-blue-500" />
            Add New Medication
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Medication Name</label>
              <Input
                type="text"
                placeholder="Enter medication name"
                value={newMed.name}
                onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Time</label>
              <Input type="time" value={newMed.time} onChange={(e) => setNewMed({ ...newMed, time: e.target.value })} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Date (Optional)</label>
              <Input type="date" value={newMed.date} onChange={(e) => setNewMed({ ...newMed, date: e.target.value })} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Frequency</label>
              <select
                className="w-full rounded-md border border-input bg-background px-3 py-2"
                value={newMed.frequency}
                onChange={(e) => setNewMed({ ...newMed, frequency: e.target.value })}
              >
                <option value="daily">Daily</option>
                <option value="twice-daily">Twice Daily</option>
                <option value="weekly">Weekly</option>
                <option value="once">Once Only</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Quick Timer (minutes)</label>
              <Input
                type="number"
                placeholder="Set a countdown timer"
                min="0"
                value={newMed.timer || ""}
                onChange={(e) => setNewMed({ ...newMed, timer: Number.parseInt(e.target.value) || 0 })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Notes (Optional)</label>
              <Input
                type="text"
                placeholder="Additional instructions"
                value={newMed.notes}
                onChange={(e) => setNewMed({ ...newMed, notes: e.target.value })}
              />
            </div>
          </div>
          <div className="mt-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <Button className="w-full md:w-auto" onClick={addMedication}>
              Add Medication
            </Button>
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">
                <input
                  type="checkbox"
                  checked={audioEnabled}
                  onChange={() => setAudioEnabled(!audioEnabled)}
                  className="mr-2"
                />
                Enable Audio Alerts
              </label>
              <Button
                size="sm"
                variant="outline"
                onClick={() => audio?.play().catch((e) => console.error("Test audio failed:", e))}
              >
                Test Audio
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming">
          {upcomingMeds.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Pill className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <p>No upcoming medications</p>
              <p className="text-sm">Add a medication to get started</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {upcomingMeds.map((med) => (
                <Card key={med.id} className="overflow-hidden">
                  <div className="flex flex-col md:flex-row">
                    <div className="p-4 md:p-6 flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold text-lg flex items-center gap-2">
                            <Pill className="h-4 w-4 text-blue-500" />
                            {med.name}
                          </h3>
                          <div className="flex items-center gap-2 text-gray-500 mt-1">
                            <Clock className="h-4 w-4" />
                            <span>
                              {med.timer ? `Timer: ${formatRemainingTime(med.nextDose)}` : formatTime(med.time)}
                            </span>
                            <Badge variant="outline">{med.frequency}</Badge>
                            {med.date && (
                              <Badge variant="outline" className="bg-blue-50">
                                {new Date(med.date).toLocaleDateString()}
                              </Badge>
                            )}
                          </div>
                          {med.notes && <p className="mt-2 text-sm text-gray-600">{med.notes}</p>}
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          onClick={() => deleteMedication(med.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                    <div className="bg-blue-50 p-4 md:p-6 flex items-center justify-center md:w-48">
                      <Button className="w-full" onClick={() => markAsTaken(med.id)}>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Mark as Taken
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="history">
          {takenMeds.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <CheckCircle className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <p>No medication history</p>
              <p className="text-sm">Your completed medications will appear here</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {takenMeds.map((med) => (
                <Card key={med.id} className="overflow-hidden">
                  <div className="p-4 flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">
                        <Pill className="h-4 w-4 text-green-500" />
                        {med.name}
                      </h3>
                      <div className="flex items-center gap-2 text-gray-500 mt-1">
                        <Clock className="h-4 w-4" />
                        <span>{formatTime(med.time)}</span>
                        <Badge variant="outline" className="bg-green-50">
                          Taken
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        Next dose: {med.nextDose.toLocaleDateString()} at {formatTime(med.time)}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      onClick={() => deleteMedication(med.id)}
                    >
                      Delete
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
      <Toaster />
    </div>
  )
}
